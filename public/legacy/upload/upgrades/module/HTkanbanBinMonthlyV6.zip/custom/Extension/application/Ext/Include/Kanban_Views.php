<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['ht_kanban_views'] = 'ht_kanban_views';
$beanFiles['ht_kanban_views'] = 'modules/ht_kanban_views/ht_kanban_views.php';
$moduleList[] = 'ht_kanban_views';

?>