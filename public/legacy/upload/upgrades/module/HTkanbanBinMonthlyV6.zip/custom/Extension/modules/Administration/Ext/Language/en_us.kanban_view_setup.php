<?php
$mod_strings['LBL_KANBANVIEW'] = 'Kanban View';
$mod_strings['LBL_KANBANVIEW_DETAIL'] = 'Use this to to Configure Kanban View';
$mod_strings['LBL_KANBANVIEW_MODULE_CONFIGURATION'] = 'Kanban Configuration';
$mod_strings['LBL_KANBANVIEW_MODULE_CONFIGURATION_DETAIL'] = 'Manage and configure the settings for Kanban view';
$mod_strings['LBL_RECYCLE_BIN_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_RECYCLE_BIN_LICENSE_DESC'] = 'Manage and configure the license for Kanban view';
?>


