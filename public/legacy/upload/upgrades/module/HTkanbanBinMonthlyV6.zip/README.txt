Kanban boards have the unique advantage of making it easy to visualize and manage the day-to-day 'work in progress'. Drag-and-drop is a core feature in any Kanban tool. When a user moves a card from one column to another the status updates automatically. With the drag-and-drop feature, moving to the next stage of business process is as easy as a single mouse move.

Kanban view configuration
Kanban configuration is our pride. Thanks to universal approach in creating new Kanban board, user can make Kanban for every module in SuiteCRM. The only requirements is dropdown list in this module. This dropdown list is used to group cards into Kanban columns. 
Users can configure by themselves what information they want to see in card header and in card body. 
Users can configure what stages they want to have on Kanban board and what stages are final for the process. 
Users can have as many Kanban boards as they needed. It is possible to have different Kanban boards for one module with different columns .
Administrator can create Kanban boards for all users. Users by themselves can modify this Kanban boards for their private usage and can add private Kanban board.